---
title: "Acwing 1063 永无乡"
date: 2021-11-09T21:46:50+08:00
draft: false
tags: ["acwing","Splay"]
categories: ["2021/11"]
---

[传送门](https://www.acwing.com/problem/content/description/1065/)

### 题意

给出$n$个岛，每个岛有权值$a[i]$，两种操作：

1. 连接两座岛
2. 询问岛$x$所在的联通块中权值第$k$小的岛的编号

### 思路

首先开$n$棵Splay，在结点中记录该结点归属于哪一棵Splay的信息$bl$，然后启发式合并Splay（把结点数小的Splay中的结点插入到大的Splay中），显然这样操作最后的复杂度是$O(nlognlog)$（~~说白了我也不会证~~）

### 代码

```c++
#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
const int maxn=2e5+5;

int n,m,q;
char opt[3];
int a[maxn];
struct node{
    int ch[2],fa,size,bl;
    int val;
}tree[maxn];
int root[maxn];

inline void pushup(int u){
    tree[u].size=tree[tree[u].ch[0]].size+tree[tree[u].ch[1]].size+1;
}

inline void rotate(int x){
    int y=tree[x].fa,z=tree[y].fa;
    int k=tree[y].ch[1]==x;
    tree[z].ch[tree[z].ch[1]==y]=x,tree[x].fa=z;
    tree[y].ch[k]=tree[x].ch[k^1],tree[tree[x].ch[k^1]].fa=y;
    tree[x].ch[k^1]=y,tree[y].fa=x;
    pushup(y),pushup(x);
}

void splay(int x,int k,int tr){
    while(tree[x].fa!=k){
        int y=tree[x].fa,z=tree[y].fa;
        if(z!=k){
            if((tree[y].ch[1]==x)^(tree[z].ch[1]==y))rotate(x);
            else rotate(y);
        }
        rotate(x);
    }
    if(!k)root[tr]=x;
}

void insert(int u,int tr){
    int fa=0,v=root[tr];
    while(v)fa=v,v=tree[v].ch[tree[u].val>tree[v].val];
    if(fa)tree[fa].ch[tree[u].val>tree[fa].val]=u;
    tree[u].ch[0]=tree[u].ch[1]=0;
    tree[u].fa=fa;
    tree[u].size=1;
    tree[u].bl=tr;
    splay(u,0,tr);
}

void dfs(int u,int tr){
    if(tree[u].ch[0])dfs(tree[u].ch[0],tr);
    if(tree[u].ch[1])dfs(tree[u].ch[1],tr);
    insert(u,tr);
}

void init(int n){
    for(int i=1;i<=n;i++){
        root[i]=i;
        tree[i].size=1;
        tree[i].val=a[i];
        tree[i].bl=i;
    }
}

void merge(int u,int v){
    int x=tree[u].bl,y=tree[v].bl;
    if(x==y)return ;
    tree[root[x]].size<tree[root[y]].size?(dfs(root[x],y),root[x]=0):(dfs(root[y],x),root[y]=0);
}

int get_k(int u,int rnk){
    while(1){
        if(tree[tree[u].ch[0]].size>=rnk)u=tree[u].ch[0];
        else if(tree[tree[u].ch[0]].size+1==rnk)return u;
        else rnk-=tree[tree[u].ch[0]].size+1,u=tree[u].ch[1];
    }
}

inline void solve(){
    int u,v;
    scanf("%d %d",&n,&m);
    for(int i=1;i<=n;i++)scanf("%d",&a[i]);
    init(n);
    while(m--){
        scanf("%d %d",&u,&v);
        merge(u,v);
    }
    scanf("%d",&q);
    while(q--){
        scanf("%s %d %d",&opt,&u,&v);
        if(opt[0]=='B')merge(u,v);
        else{
            if(tree[root[tree[u].bl]].size<v)puts("-1");
            else printf("%d\n",get_k(root[tree[u].bl],v));
        }
    }
}

int main(){
    int __=1;
    while(__--){
        solve();
    }
    return 0;
}
```

### 小结

思路几乎是看完题就想到了，实现的过程真是一言难尽，各种小错误不断，从dfs插入的顺序不对，到递归版查找第$k$大没有返回值，然后到Splay的旋转向上更新写反，每一个错误都是很不应该的，修bug足足修了两天，实在是对自己的状态担忧
