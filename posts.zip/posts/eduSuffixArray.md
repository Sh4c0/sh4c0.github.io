---
title: "Codeforces Edu SuffixArray"
date: 2021-10-02T16:13:17+08:00
draft: false
tags: ["codeforces","EDU","suffix array"]
categories: ["2021/10"]
---

[传送门](https://codeforces.com/edu/course/2/lesson/2)

# step1

## A. Suffix Array - 1

### 题意

求后缀数组

### 思路

直接上板子

### 代码

```c++
#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+5;
const int maxm=1e9;

int n,m;
int N,M,rk[maxn],sa[maxn],tp[maxn],tax[maxn],px[maxn],ht[maxn];
char s[maxn];
 
void ssort(){
    for(int i=0;i<=M;i++)tax[i]=0;
    for(int i=1;i<=N;i++)tax[px[i]=rk[tp[i]]]++;
    for(int i=1;i<=M;i++)tax[i]+=tax[i-1];
    for(int i=N;i>0;i--)sa[tax[px[i]]--]=tp[i];
}
 
inline bool cmp(int x,int y,int w){
    return tp[x]==tp[y]&&tp[x+w]==tp[y+w];
}
 
void SuffixArray(){
    M=300;
    N=strlen(s+1);
    memset(rk,0,sizeof rk);
    for(int i=1;i<=N;i++)rk[i]=s[i],tp[i]=i;
    ssort();
    for(int w=1,p=0;p<N;M=p,w<<=1){
        p=0;
        for(int i=1;i<=w;i++)tp[++p]=N-w+i;
        for(int i=1;i<=N;i++)if(sa[i]>w)tp[++p]=sa[i]-w;
        ssort();
        memcpy(tp,rk,sizeof rk);
        rk[sa[1]]=p=1;
        for(int i=2;i<=N;i++)rk[sa[i]]=cmp(sa[i],sa[i-1],w)?p:++p;
    }
}

char tmp[maxn];

inline void solve(){
    cin>>(tmp+1);
    n=strlen(tmp+1);
    for(int i=1;i<=n;i++)s[i]=tmp[i];
    s[n+1]='$';
    SuffixArray();
    for(int i=1;i<=N;i++)cout<<sa[i]-1<<" ";
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int __=1;
    while(__--){
        solve();
    }
    return 0;
}
```

# step2

## A. Suffix Array - 2

### 题意

更快的求后缀数组

### 思路

同样直接上板子

### 代码

```c++
#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+5;
const int maxm=1e9;

int n,m;
int N,M,rk[maxn],sa[maxn],tp[maxn],tax[maxn],px[maxn],ht[maxn];
char s[maxn];
 
void ssort(){
    for(int i=0;i<=M;i++)tax[i]=0;
    for(int i=1;i<=N;i++)tax[px[i]=rk[tp[i]]]++;
    for(int i=1;i<=M;i++)tax[i]+=tax[i-1];
    for(int i=N;i>0;i--)sa[tax[px[i]]--]=tp[i];
}
 
inline bool cmp(int x,int y,int w){
    return tp[x]==tp[y]&&tp[x+w]==tp[y+w];
}
 
void SuffixArray(){
    M=300;
    N=strlen(s+1);
    memset(rk,0,sizeof rk);
    for(int i=1;i<=N;i++)rk[i]=s[i],tp[i]=i;
    ssort();
    for(int w=1,p=0;p<N;M=p,w<<=1){
        p=0;
        for(int i=1;i<=w;i++)tp[++p]=N-w+i;
        for(int i=1;i<=N;i++)if(sa[i]>w)tp[++p]=sa[i]-w;
        ssort();
        memcpy(tp,rk,sizeof rk);
        rk[sa[1]]=p=1;
        for(int i=2;i<=N;i++)rk[sa[i]]=cmp(sa[i],sa[i-1],w)?p:++p;
    }
}

char tmp[maxn];

inline void solve(){
    cin>>(tmp+1);
    n=strlen(tmp+1);
    for(int i=1;i<=n;i++)s[i]=tmp[i];
    s[n+1]='$';
    SuffixArray();
    for(int i=1;i<=N;i++)cout<<sa[i]-1<<" ";
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int __=1;
    while(__--){
        solve();
    }
    return 0;
}
```

# step3

## A. Substring Search

### 题意

给定字符串$t$，$n$次询问，给定字符串$s_i$是否为$t$的子串

### 思路

得出后缀数组之后，在后缀数组中二分查找即可

### 代码

```c++
#include<bits/stdc++.h>
using namespace std;
const int maxn=3e5+5;

int n,m;
int N,M,rk[maxn],sa[maxn],tp[maxn],tax[maxn],px[maxn],ht[maxn];
char s[maxn];
 
void ssort(){
    for(int i=0;i<=M;i++)tax[i]=0;
    for(int i=1;i<=N;i++)tax[px[i]=rk[tp[i]]]++;
    for(int i=1;i<=M;i++)tax[i]+=tax[i-1];
    for(int i=N;i>0;i--)sa[tax[px[i]]--]=tp[i];
}
 
inline bool cmp(int x,int y,int w){
    return tp[x]==tp[y]&&tp[x+w]==tp[y+w];
}
 
void SuffixArray(){
    M=300;
    N=strlen(s+1);
    memset(rk,0,sizeof rk);
    for(int i=1;i<=N;i++)rk[i]=s[i],tp[i]=i;
    ssort();
    for(int w=1,p=0;p<N;M=p,w<<=1){
        p=0;
        for(int i=1;i<=w;i++)tp[++p]=N-w+i;
        for(int i=1;i<=N;i++)if(sa[i]>w)tp[++p]=sa[i]-w;
        ssort();
        memcpy(tp,rk,sizeof rk);
        rk[sa[1]]=p=1;
        for(int i=2;i<=N;i++)rk[sa[i]]=cmp(sa[i],sa[i-1],w)?p:++p;
    }
}

char tmp[maxn];
int len;

bool check(int x){
    x=sa[x];
    for(int i=0;i<min(len,N-x+1);i++){
        if(s[x+i]>tmp[i+1])return 1;
        else if(s[x+i]<tmp[i+1])return 0;
    }
    return len<=N-x+1;
}

int bsearch_1(int l,int r){
    len=strlen(tmp+1);
    while(l<r){
        int mid=(l+r)>>1;
        if(check(mid))r=mid;
        else l=mid+1;
    }
    l=sa[l];
    if(len>N-l+1)return 0;
    for(int i=0;i<min(len,N-l+1);i++){
        if(s[l+i]!=tmp[i+1]){
            return 0;
        }
    }
    return 1;
}

inline void solve(){
    cin>>(s+1)>>n;
    SuffixArray();
    for(int i=1;i<=n;i++){
        cin>>(tmp+1);
        if(bsearch_1(1,N))cout<<"Yes"<<endl;
        else cout<<"No"<<endl;
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int __=1;
    while(__--){
        solve();
    }
    return 0;
}
```

## B. Counting Substrings

### 题意

给定字符串$t$，$n$次询问，给定字符串$s_i$在$t$中出现的次数

### 思路

二分查找找出第一个字典序比$s_i$小的和第一个比$s_i$大的即可

### 代码

```c++
#include<bits/stdc++.h>
using namespace std;
const int maxn=3e5+5;

int n,m;
int N,M,rk[maxn],sa[maxn],tp[maxn],tax[maxn],px[maxn],ht[maxn];
char s[maxn];
 
void ssort(){
    for(int i=0;i<=M;i++)tax[i]=0;
    for(int i=1;i<=N;i++)tax[px[i]=rk[tp[i]]]++;
    for(int i=1;i<=M;i++)tax[i]+=tax[i-1];
    for(int i=N;i>0;i--)sa[tax[px[i]]--]=tp[i];
}
 
inline bool cmp(int x,int y,int w){
    return tp[x]==tp[y]&&tp[x+w]==tp[y+w];
}
 
void SuffixArray(){
    M=300;
    N=strlen(s+1);
    memset(rk,0,sizeof rk);
    for(int i=1;i<=N;i++)rk[i]=s[i],tp[i]=i;
    ssort();
    for(int w=1,p=0;p<N;M=p,w<<=1){
        p=0;
        for(int i=1;i<=w;i++)tp[++p]=N-w+i;
        for(int i=1;i<=N;i++)if(sa[i]>w)tp[++p]=sa[i]-w;
        ssort();
        memcpy(tp,rk,sizeof rk);
        rk[sa[1]]=p=1;
        for(int i=2;i<=N;i++)rk[sa[i]]=cmp(sa[i],sa[i-1],w)?p:++p;
    }
}

char tmp[maxn];
int len;

bool check1(int x){
    string a(tmp+1),b;
    x=sa[x];
    for(int i=0;i<min(N-x+1,len);i++)b.push_back(s[x+i]);
    return b>=a;
}

int bsearch_1(int l,int r){
    while(l<r){
        int mid=(l+r)>>1;
        if(check1(mid))r=mid;
        else l=mid+1;
    }
    return l;
}

bool check2(int x){
    string a(tmp+1),b;
    x=sa[x];
    for(int i=0;i<min(N-x+1,len);i++)b.push_back(s[x+i]);
    return b>a;
}

int bsearch_2(int l,int r){
    while(l<r){
        int mid=(l+r+1)>>1;
        if(check2(mid))r=mid-1;
        else l=mid;
    }
    return l;
}

inline void solve(){
    cin>>(s+1)>>n;
    SuffixArray();
    for(int i=1;i<=n;i++){
        cin>>(tmp+1);
        len=strlen(tmp+1);
        int ans1=bsearch_2(1,N),ans2=bsearch_1(1,N);
        string a(tmp+1),b;
        for(int i=0;i<min(N-sa[ans2]+1,len);i++)b.push_back(s[sa[ans2]+i]);
        if(a!=b)cout<<0<<endl;
        else cout<<ans1-ans2+1<<endl;
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int __=1;
    while(__--){
        solve();
    }
    return 0;
}
```

# step4

## A. Suffix Array and LCP

### 题意

求后缀数组以及$height$数组

### 思路

直接上板子

### 代码

```c++
#include<bits/stdc++.h>
using namespace std;
const int maxn=3e5+5;

int n,m;
int N,M,rk[maxn],sa[maxn],tp[maxn],tax[maxn],px[maxn],ht[maxn];
char s[maxn];
 
void ssort(){
    for(int i=0;i<=M;i++)tax[i]=0;
    for(int i=1;i<=N;i++)tax[px[i]=rk[tp[i]]]++;
    for(int i=1;i<=M;i++)tax[i]+=tax[i-1];
    for(int i=N;i>0;i--)sa[tax[px[i]]--]=tp[i];
}
 
inline bool cmp(int x,int y,int w){
    return tp[x]==tp[y]&&tp[x+w]==tp[y+w];
}
 
void SuffixArray(){
    M=300;
    N=strlen(s+1);
    memset(rk,0,sizeof rk);
    for(int i=1;i<=N;i++)rk[i]=s[i]+1,tp[i]=i;
    ssort();
    for(int w=1,p=0;p<N;M=p,w<<=1){
        p=0;
        for(int i=1;i<=w;i++)tp[++p]=N-w+i;
        for(int i=1;i<=N;i++)if(sa[i]>w)tp[++p]=sa[i]-w;
        ssort();
        memcpy(tp,rk,sizeof rk);
        rk[sa[1]]=p=1;
        for(int i=2;i<=N;i++)rk[sa[i]]=cmp(sa[i],sa[i-1],w)?p:++p;
    }
}
 
void Height(){
    int j,k=0;
    for(int i=1;i<=N;i++){
        if(k)k--;
        int j=sa[rk[i]-1];
        while(s[i+k]==s[j+k])k++;
        ht[rk[i]]=k;
    }
}

inline void solve(){
    string str;
    cin>>str;
    str.push_back('$');
    for(int i=0;i<str.size();i++)s[i+1]=str[i];
    SuffixArray();
    for(int i=1;i<=N;i++)cout<<sa[i]-1<<" ";
    cout<<endl;
    Height();
    for(int i=2;i<=N;i++)cout<<ht[i]<<" ";
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int __=1;
    while(__--){
        solve();
    }
    return 0;
}

```

# step5

## A. Number of Different Substrings

### 题意

对于给定字符串$s$，求出其不同子串的数量

### 思路

对于后缀$sa[i]$和后缀$sa[i+1]$，后缀$sa[i+1]$的贡献为其长度减去与后缀$sa[i]$部分，所以不同子串的数量为$n(n-1)/2-\sum_{i=1}^n height[i]$

### 代码

```c++
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=4e5+5;

int n,m;
int N,M,rk[maxn],sa[maxn],tp[maxn],tax[maxn],px[maxn],ht[maxn];
char s[maxn];
 
void ssort(){
    for(int i=0;i<=M;i++)tax[i]=0;
    for(int i=1;i<=N;i++)tax[px[i]=rk[tp[i]]]++;
    for(int i=1;i<=M;i++)tax[i]+=tax[i-1];
    for(int i=N;i>0;i--)sa[tax[px[i]]--]=tp[i];
}
 
inline bool cmp(int x,int y,int w){
    return tp[x]==tp[y]&&tp[x+w]==tp[y+w];
}
 
void SuffixArray(){
    M=75;
    N=strlen(s+1);
    memset(rk,0,sizeof rk);
    for(int i=1;i<=N;i++)rk[i]=s[i]-'0'+1,tp[i]=i;
    ssort();
    for(int w=1,p=0;p<N;M=p,w<<=1){
        p=0;
        for(int i=1;i<=w;i++)tp[++p]=N-w+i;
        for(int i=1;i<=N;i++)if(sa[i]>w)tp[++p]=sa[i]-w;
        ssort();
        memcpy(tp,rk,sizeof rk);
        rk[sa[1]]=p=1;
        for(int i=2;i<=N;i++)rk[sa[i]]=cmp(sa[i],sa[i-1],w)?p:++p;
    }
}
 
void Height(){
    int j,k=0;
    for(int i=1;i<=N;i++){
        if(k)k--;
        int j=sa[rk[i]-1];
        while(s[i+k]==s[j+k])k++;
        ht[rk[i]]=k;
    }
}

inline void solve(){
    cin>>(s+1);
    SuffixArray();
    Height();
    ll ans=0;
    for(int i=1;i<=N;i++)ans+=(ll)sa[i]-ht[i];
    cout<<ans<<endl;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int __=1;
    while(__--){
        solve();
    }
    return 0;
}
```

## B. Longest Common Substring

### 题意

给定字符串$s$和$t$，输出其最长公共子串

### 思路

首先将两个字符串拼接在一起用$分隔

很容易想到两个字符串中以最长公共子串味首的后缀在后缀数组中必然相邻，所以在$height$数组中找出两个后缀来自不同的字符串且值最大的位置即可

### 代码

```c++
#include<bits/stdc++.h>
using namespace std;
const int maxn=4e5+5;

int n,m;
int N,M,rk[maxn],sa[maxn],tp[maxn],tax[maxn],px[maxn],ht[maxn];
char s[maxn];
 
void ssort(){
    for(int i=0;i<=M;i++)tax[i]=0;
    for(int i=1;i<=N;i++)tax[px[i]=rk[tp[i]]]++;
    for(int i=1;i<=M;i++)tax[i]+=tax[i-1];
    for(int i=N;i>0;i--)sa[tax[px[i]]--]=tp[i];
}
 
inline bool cmp(int x,int y,int w){
    return tp[x]==tp[y]&&tp[x+w]==tp[y+w];
}
 
void SuffixArray(){
    M=300;
    N=strlen(s+1);
    memset(rk,0,sizeof rk);
    for(int i=1;i<=N;i++)rk[i]=s[i]+1,tp[i]=i;
    ssort();
    for(int w=1,p=0;p<N;M=p,w<<=1){
        p=0;
        for(int i=1;i<=w;i++)tp[++p]=N-w+i;
        for(int i=1;i<=N;i++)if(sa[i]>w)tp[++p]=sa[i]-w;
        ssort();
        memcpy(tp,rk,sizeof rk);
        rk[sa[1]]=p=1;
        for(int i=2;i<=N;i++)rk[sa[i]]=cmp(sa[i],sa[i-1],w)?p:++p;
    }
}
 
void Height(){
    int j,k=0;
    for(int i=1;i<=N;i++){
        if(k)k--;
        int j=sa[rk[i]-1];
        while(s[i+k]==s[j+k])k++;
        ht[rk[i]]=k;
    }
}

inline void solve(){
    string s1,s2;
    cin>>s1>>s2;
    int len1=s1.size(),len2=s2.size();
    s1+='$';
    s1+=s2;
    for(int i=0;i<s1.size();i++)s[i+1]=s1[i];
    SuffixArray();
    Height();
    int ans=1;
    for(int i=2;i<=N;i++){
        if(sa[i]<=len1&&sa[i-1]>len1+1&&ht[ans]<ht[i])ans=i;
        if(sa[i-1]<=len1&&sa[i]>len1+1&&ht[ans]<ht[i])ans=i;
    }
    for(int i=0;i<ht[ans];i++)cout<<s[sa[ans]+i];
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int __=1;
    while(__--){
        solve();
    }
    return 0;
}
```

## C. Sorting Substrings

### 题意

给定字符串$s$以及其$n$个子串，将其排序后输出（子串均以$l,r$的方式给出以及输出）

### 思路

对于子串$[l_i,r_i]$和$[l_j,r_j]$，当$lcp(l_i,l_j) \geqslant min(r_i-l_i+1,r_j-l_j+1)$，则只需要比较其长度即可，否则则比较$rank[l_i]$和$rank[l_j]$

### 代码

```c++
#include<bits/stdc++.h>
using namespace std;
#define x first
#define y second
typedef pair<int,int> P;
const int maxn=4e5+5;

int n,m;
int N,M,rk[maxn],sa[maxn],tp[maxn],tax[maxn],px[maxn],ht[maxn];
char s[maxn];
 
void ssort(){
    for(int i=0;i<=M;i++)tax[i]=0;
    for(int i=1;i<=N;i++)tax[px[i]=rk[tp[i]]]++;
    for(int i=1;i<=M;i++)tax[i]+=tax[i-1];
    for(int i=N;i>0;i--)sa[tax[px[i]]--]=tp[i];
}
 
inline bool cmp(int x,int y,int w){
    return tp[x]==tp[y]&&tp[x+w]==tp[y+w];
}
 
void SuffixArray(){
    M=300;
    N=strlen(s+1);
    memset(rk,0,sizeof rk);
    for(int i=1;i<=N;i++)rk[i]=s[i]+1,tp[i]=i;
    ssort();
    for(int w=1,p=0;p<N;M=p,w<<=1){
        p=0;
        for(int i=1;i<=w;i++)tp[++p]=N-w+i;
        for(int i=1;i<=N;i++)if(sa[i]>w)tp[++p]=sa[i]-w;
        ssort();
        memcpy(tp,rk,sizeof rk);
        rk[sa[1]]=p=1;
        for(int i=2;i<=N;i++)rk[sa[i]]=cmp(sa[i],sa[i-1],w)?p:++p;
    }
}
 
void Height(){
    int j,k=0;
    for(int i=1;i<=N;i++){
        if(k)k--;
        int j=sa[rk[i]-1];
        while(s[i+k]==s[j+k])k++;
        ht[rk[i]]=k;
    }
}

int st[maxn][30],plg[maxn];

void ST_pre(){
    plg[1]=0;
    for(int i=2;i<=N;i++)plg[i]=plg[i/2]+1;
    for(int i=1;i<=N;i++)st[i][0]=ht[i];
    for(int j=1;j<=plg[N];j++){
        for(int i=1;i<=N-(1<<j)+1;i++){
            st[i][j]=min(st[i][j-1],st[i+(1<<(j-1))][j-1]);
        }
    }
}

int ST_query(int l,int r){
    int k=plg[r-l+1];
    return min(st[l][k],st[r-(1<<k)+1][k]);
}

int lcp(int a,int b){//第a个后缀与第b个后缀的最长公共前缀
    a=rk[a],b=rk[b];
    if(a>b)swap(a,b);
    return ST_query(a+1,b);
}

vector<P> v;

bool f(P a,P b){
    int lena=a.y-a.x+1;
    int lenb=b.y-b.x+1;
    int len=lcp(a.x,b.x);
    if(a.x==b.x)len=inf;
    if(len>=min(lena,lenb)){
        if(lena<lenb)return 1;
        else if(lena>lenb)return 0;
        else if(a.x<b.x)return 1;
        else if(a.x>b.x)return 0;
        else return a.y<b.y;
    }
    return rk[a.x]<rk[b.x];
}

inline void solve(){
    cin>>(s+1);
    SuffixArray();
    Height();
    ST_pre();
    cin>>n;
    int a,b;
    for(int i=0;i<n;i++){
        cin>>a>>b;
        v.push_back(P(a,b));
    }
    sort(v.begin(),v.end(),f);
    for(int i=0;i<n;i++)cout<<v[i].x<<" "<<v[i].y<<endl;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int __=1;
    while(__--){
        solve();
    }
    return 0;
}
```

## D. Borders

### 题意

如果一个字符串同时是另一个字符串的前缀和后缀，则称这个字符串为另一个字符串的$border$

对于给定串$s$，输出其所有子串的$border$数量之和

### 思路

对于后缀$i$和后缀$j$这对后缀的贡献为$lcp(i,j)$，因此答案为$\sum_{i=1}^n \sum_{j=i}^nlcp(i,j)$

而$lcp(i,j)$本质为$min\{height[i+1...j]\}$

因此问题变成了求height数组的子数组最小值之和，用单调栈和dp优化这个过程

构造递增的单调栈，定义$sum[i]$为以$i$为右端点的区间最小值之和，对于$i$我们找到第一个比$i$小的位置$j$，$sum[i]$由两部分构成，左端点在$j$的右侧的子数组之和为$(i-j)*height[i]$，而左端点在$j$的左侧的子数组之和为$sum[j]$，所以$sum[i]=(i-j)*height[i]+sum[j]$

### 代码

```c++
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=4e5+5;

int n,m;
int N,M,rk[maxn],sa[maxn],tp[maxn],tax[maxn],px[maxn],ht[maxn];
char s[maxn];
 
void ssort(){
    for(int i=0;i<=M;i++)tax[i]=0;
    for(int i=1;i<=N;i++)tax[px[i]=rk[tp[i]]]++;
    for(int i=1;i<=M;i++)tax[i]+=tax[i-1];
    for(int i=N;i>0;i--)sa[tax[px[i]]--]=tp[i];
}
 
inline bool cmp(int x,int y,int w){
    return tp[x]==tp[y]&&tp[x+w]==tp[y+w];
}
 
void SuffixArray(){
    M=300;
    N=strlen(s+1);
    memset(rk,0,sizeof rk);
    for(int i=1;i<=N;i++)rk[i]=s[i]+1,tp[i]=i;
    ssort();
    for(int w=1,p=0;p<N;M=p,w<<=1){
        p=0;
        for(int i=1;i<=w;i++)tp[++p]=N-w+i;
        for(int i=1;i<=N;i++)if(sa[i]>w)tp[++p]=sa[i]-w;
        ssort();
        memcpy(tp,rk,sizeof rk);
        rk[sa[1]]=p=1;
        for(int i=2;i<=N;i++)rk[sa[i]]=cmp(sa[i],sa[i-1],w)?p:++p;
    }
}
 
void Height(){
    int j,k=0;
    for(int i=1;i<=N;i++){
        if(k)k--;
        int j=sa[rk[i]-1];
        while(s[i+k]==s[j+k])k++;
        ht[rk[i]]=k;
    }
}

stack<int> st;
ll sum[maxn];

inline void solve(){
    cin>>(s+1);
    SuffixArray();
    Height();
    ll ans=0;
    for(int i=1;i<=N;i++)ans+=i;
    for(ll i=2;i<=N;i++){
        while(!st.empty()&&ht[st.top()]>=ht[i])st.pop();
        sum[i]=st.empty()?(i-1)*ht[i]:(i-st.top())*ht[i]+sum[st.top()];
        st.push(i);
    }
    for(int i=2;i<=N;i++)ans+=sum[i];
    cout<<ans<<endl;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int __=1;
    while(__--){
        solve();
    }
    return 0;
}
```

## E. Refrain

### 题意

对给定字符串$s$，找到子串$t$，$t$满足出现次数与字符串长度的乘积在所有子串中最大

### 思路

对于任意子串为首的后缀其在后缀数组中出现都是连续的，该问题可以化简为在$height$数组中求最大矩形

利用单调栈找出对于任意$height[i]$左侧和右侧第一个比$height[i]$小的位置记为$pre[i]$和$nxt[i]$，$height[i]*(nxt[i]-pre[i])$即为以$height[i]$为高宽度最宽的矩形，求出最值即可

### 代码

```c++
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=4e5+5;

int n,m;

int N,M,rk[maxn],sa[maxn],tp[maxn],tax[maxn],px[maxn],ht[maxn];
char s[maxn];
 
void ssort(){
    for(int i=0;i<=M;i++)tax[i]=0;
    for(int i=1;i<=N;i++)tax[px[i]=rk[tp[i]]]++;
    for(int i=1;i<=M;i++)tax[i]+=tax[i-1];
    for(int i=N;i>0;i--)sa[tax[px[i]]--]=tp[i];
}
 
inline bool cmp(int x,int y,int w){
    return tp[x]==tp[y]&&tp[x+w]==tp[y+w];
}
 
void SuffixArray(){
    M=300;
    N=strlen(s+1);
    memset(rk,0,sizeof rk);
    for(int i=1;i<=N;i++)rk[i]=s[i]+1,tp[i]=i;
    ssort();
    for(int w=1,p=0;p<N;M=p,w<<=1){
        p=0;
        for(int i=1;i<=w;i++)tp[++p]=N-w+i;
        for(int i=1;i<=N;i++)if(sa[i]>w)tp[++p]=sa[i]-w;
        ssort();
        memcpy(tp,rk,sizeof rk);
        rk[sa[1]]=p=1;
        for(int i=2;i<=N;i++)rk[sa[i]]=cmp(sa[i],sa[i-1],w)?p:++p;
    }
}
 
void Height(){
    int j,k=0;
    for(int i=1;i<=N;i++){
        if(k)k--;
        int j=sa[rk[i]-1];
        while(s[i+k]==s[j+k])k++;
        ht[rk[i]]=k;
    }
}

stack<int> st;
ll pre[maxn],nxt[maxn];

inline void solve(){
    cin>>n>>m;
    int c;
    string ss;
    for(int i=1;i<=n;i++){
        cin>>c;
        s[i]='a'+c;
    }
    SuffixArray();
    Height();
    ll ans=N;
    for(int i=2;i<=N;i++){
        while(st.size()&&ht[i]<=ht[st.top()])st.pop();
        pre[i]=st.size()?st.top():1;
        st.push(i);
    }
    while(st.size())st.pop();
    for(int i=N;i>=2;i--){
        while(st.size()&&ht[i]<=ht[st.top()])st.pop();
        nxt[i]=st.size()?st.top():N+1;
        st.push(i);
    }
    int len=0,id=0;
    for(int i=2;i<=N;i++){
        if((nxt[i]-pre[i])*ht[i]>ans||((nxt[i]-pre[i])*ht[i]==ans&&(nxt[i]-pre[i])<len)){
            ans=(nxt[i]-pre[i])*ht[i];
            len=nxt[i]-pre[i];
            id=i;
        }
    }
    if(ans==N){
        cout<<N<<endl;
        cout<<N<<endl;
        for(int i=1;i<=N;i++)cout<<s[i]-'a'<<" ";
        return ;
    }
    cout<<ans<<endl;
    cout<<ans/len<<endl;
    for(int i=0;i<ans/len;i++)cout<<s[sa[id]+i]-'a'<<" ";
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int __=1;
    while(__--){
        solve();
    }
    return 0;
}
```

## F. Periodic Substring

### 题意

求出重复次数最多的连续子串

### 思路

枚举子串长度为$i$，如果子串中循环节重复次数不少于两次，那么**字符**$s[0],s[i],s[2*i],s[3*i]...$必然会有两个或两个以上出现在该子串中，不妨设前两个字符为$s[j],s[j+i]$，我们记$lcp(j,j+i)$为$cnt$我们考虑两种情况

1. 如果$s[j]$是子串的首字符，那么该子串的循环节重复次数为$cnt/i$，此时子串为$s[j...j+i+cnt-cnt\%i]$
2. 否则，$s[j]$左侧的$i-cnt\%i$个字符有可能可以继续拼凑出一个循环节，我们记此时的起点$j-(i-cnt\%i)$为$k$，当$lcp(k,k+i) \geqslant i$则可以拼凑，此时子串为$s[k...j+i+cnt]$

### 代码

```c++
#include<bits/stdc++.h>
using namespace std;
const int maxn=4e5+5;

int n,m;
int N,M,rk[maxn],sa[maxn],tp[maxn],tax[maxn],px[maxn],ht[maxn];
char s[maxn];
 
void ssort(){
    for(int i=0;i<=M;i++)tax[i]=0;
    for(int i=1;i<=N;i++)tax[px[i]=rk[tp[i]]]++;
    for(int i=1;i<=M;i++)tax[i]+=tax[i-1];
    for(int i=N;i>0;i--)sa[tax[px[i]]--]=tp[i];
}
 
inline bool cmp(int x,int y,int w){
    return tp[x]==tp[y]&&tp[x+w]==tp[y+w];
}
 
void SuffixArray(){
    M=75;
    N=strlen(s+1);
    memset(rk,0,sizeof rk);
    for(int i=1;i<=N;i++)rk[i]=s[i]-'0'+1,tp[i]=i;
    ssort();
    for(int w=1,p=0;p<N;M=p,w<<=1){
        p=0;
        for(int i=1;i<=w;i++)tp[++p]=N-w+i;
        for(int i=1;i<=N;i++)if(sa[i]>w)tp[++p]=sa[i]-w;
        ssort();
        memcpy(tp,rk,sizeof rk);
        rk[sa[1]]=p=1;
        for(int i=2;i<=N;i++)rk[sa[i]]=cmp(sa[i],sa[i-1],w)?p:++p;
    }
}
 
void Height(){
    int j,k=0;
    for(int i=1;i<=N;i++){
        if(k)k--;
        int j=sa[rk[i]-1];
        while(s[i+k]==s[j+k])k++;
        ht[rk[i]]=k;
    }
}

int st[maxn][30],plg[maxn];

void ST_pre(){
    plg[1]=0;
    for(int i=2;i<=N;i++)plg[i]=plg[i/2]+1;
    for(int i=1;i<=N;i++)st[i][0]=ht[i];
    for(int j=1;j<=plg[N];j++){
        for(int i=1;i<=N-(1<<j)+1;i++){
            st[i][j]=min(st[i][j-1],st[i+(1<<(j-1))][j-1]);
        }
    }
}

int ST_query(int l,int r){
    int k=plg[r-l+1];
    return min(st[l][k],st[r-(1<<k)+1][k]);
}

int lcp(int a,int b){//第a个后缀与第b个后缀的最长公共前缀
    a=rk[a],b=rk[b];
    if(a>b)swap(a,b);
    return ST_query(a+1,b);
}

inline void solve(){
    cin>>(s+1);
    SuffixArray();
    Height();
    ST_pre();
    int ans=1;
    for(int i=1;i<=N;i++){
        for(int j=1;j+i<=N;j+=i){
            int cnt=lcp(j,j+i);
            int k=j-(i-cnt%i);
            cnt=cnt/i+1;
            if(k>=1&&lcp(k,k+i)>=i)cnt++;
            ans=max(cnt,ans);
        }
    }
    cout<<ans<<endl;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int __=1;
    while(__--){
        solve();
    }
    return 0;
}
```

# 小结

通过这么多题算是对后缀数组有了一个初步的了解，感叹一下还是自己会的东西太少了，在做与单调栈结合的题目费了很大的功夫

后缀数组的学习到这里算是告一段落了
